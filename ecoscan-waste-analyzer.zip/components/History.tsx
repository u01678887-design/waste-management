
import React from 'react';
import { ScanHistoryItem } from '../types';

interface HistoryProps {
  history: ScanHistoryItem[];
  onSelectItem: (item: ScanHistoryItem) => void;
}

const History: React.FC<HistoryProps> = ({ history, onSelectItem }) => {
  if (history.length === 0) return null;

  return (
    <div className="mt-12 mb-8">
      <div className="flex items-center justify-between mb-4 px-2">
        <h3 className="text-lg font-bold text-gray-800">Recent Scans</h3>
        <span className="text-xs text-gray-400">{history.length} items saved</span>
      </div>
      
      <div className="space-y-3">
        {history.map((item) => (
          <div 
            key={item.id}
            onClick={() => onSelectItem(item)}
            className="bg-white p-3 rounded-2xl flex items-center space-x-4 border border-gray-100 hover:border-emerald-200 hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-gray-100">
              <img 
                src={item.imageUrl} 
                alt={item.itemName}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-bold text-gray-800 truncate">{item.itemName}</h4>
              <div className="flex items-center space-x-2 mt-1">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                  item.category === 'Recyclable' ? 'bg-blue-50 text-blue-600' :
                  item.category === 'Compostable' ? 'bg-emerald-50 text-emerald-600' :
                  'bg-gray-50 text-gray-600'
                }`}>
                  {item.category}
                </span>
                <span className="text-[10px] text-gray-400">
                  {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
            <div className="pr-2">
              <i className="fas fa-chevron-right text-gray-300 text-sm group-hover:text-emerald-400 group-hover:translate-x-1 transition-all"></i>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default History;
