
import React, { useRef, useEffect, useState, useCallback } from 'react';

interface CameraViewProps {
  onCapture: (base64Image: string) => void;
  isAnalyzing: boolean;
}

const CameraView: React.FC<CameraViewProps> = ({ onCapture, isAnalyzing }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setHasPermission(true);
    } catch (err) {
      console.error('Error accessing camera:', err);
      setHasPermission(false);
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        onCapture(base64);
      }
    }
  };

  if (hasPermission === false) {
    return (
      <div className="bg-red-50 p-8 rounded-2xl text-center border-2 border-dashed border-red-200">
        <i className="fas fa-camera-slash text-4xl text-red-400 mb-4"></i>
        <p className="text-red-800 font-medium">Camera access denied</p>
        <p className="text-red-600 text-sm mt-2">Please enable camera permissions to scan waste.</p>
        <button 
          onClick={startCamera}
          className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-[3/4] max-h-[500px] bg-black rounded-3xl overflow-hidden shadow-2xl group">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />
      
      <canvas ref={canvasRef} className="hidden" />

      {/* Viewfinder overlay */}
      <div className="absolute inset-0 border-[40px] border-black/20 pointer-events-none flex items-center justify-center">
        <div className="w-48 h-48 border-2 border-white/50 rounded-3xl border-dashed"></div>
      </div>

      <div className="absolute bottom-6 left-0 right-0 flex justify-center px-6">
        <button
          onClick={captureFrame}
          disabled={isAnalyzing}
          className={`
            w-16 h-16 rounded-full border-4 border-white flex items-center justify-center
            ${isAnalyzing ? 'bg-gray-400 cursor-not-allowed scale-90' : 'bg-emerald-500 hover:bg-emerald-400 active:scale-95 transition-all'}
          `}
        >
          {isAnalyzing ? (
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <div className="w-12 h-12 rounded-full border-2 border-white/30"></div>
          )}
        </button>
      </div>

      {isAnalyzing && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center text-white">
          <div className="relative w-24 h-24 mb-4">
             <div className="absolute inset-0 border-4 border-emerald-500 rounded-full animate-ping opacity-20"></div>
             <div className="absolute inset-2 border-4 border-emerald-400 rounded-full animate-pulse opacity-40"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                <i className="fas fa-brain text-4xl text-emerald-300"></i>
             </div>
          </div>
          <p className="text-lg font-medium animate-pulse">Analyzing material...</p>
          <p className="text-xs text-white/60 mt-2">Gemini is identifying your item</p>
        </div>
      )}
    </div>
  );
};

export default CameraView;
