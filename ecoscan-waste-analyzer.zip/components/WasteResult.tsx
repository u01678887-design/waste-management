
import React from 'react';
import { WasteAnalysis } from '../types';

interface WasteResultProps {
  analysis: WasteAnalysis;
  onReset: () => void;
}

const WasteResult: React.FC<WasteResultProps> = ({ analysis, onReset }) => {
  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Recyclable': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Compostable': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Hazardous': return 'bg-red-100 text-red-700 border-red-200';
      case 'E-Waste': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Landfill': return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getScoreColor = (score: number) => {
    if (score > 75) return 'text-emerald-500';
    if (score > 40) return 'text-amber-500';
    return 'text-red-500';
  };

  return (
    <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-gray-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <span className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${getCategoryColor(analysis.category)}`}>
              {analysis.category}
            </span>
            <h2 className="text-2xl font-bold text-gray-800 mt-2">{analysis.itemName}</h2>
            <p className="text-gray-500 text-sm italic">{analysis.materialType}</p>
          </div>
          <div className="text-center">
            <div className={`text-3xl font-black ${getScoreColor(analysis.recyclabilityScore)}`}>
              {analysis.recyclabilityScore}%
            </div>
            <div className="text-[10px] text-gray-400 font-bold uppercase">Recyclable</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div className="flex items-center space-x-2 text-slate-600 mb-2">
              <i className="fas fa-trash-arrow-up"></i>
              <span className="font-bold text-sm uppercase">Disposal Guide</span>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">{analysis.disposalInstructions}</p>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
            <div className="flex items-center space-x-2 text-emerald-600 mb-2">
              <i className="fas fa-lightbulb"></i>
              <span className="font-bold text-sm uppercase">Eco-Tip</span>
            </div>
            <p className="text-sm text-emerald-700 leading-relaxed">{analysis.sustainabilityTip}</p>
          </div>
        </div>

        <div className="bg-gray-900 text-gray-100 p-4 rounded-2xl mb-6">
          <div className="flex items-center space-x-2 text-gray-400 mb-2">
            <i className="fas fa-earth-americas"></i>
            <span className="font-bold text-xs uppercase tracking-widest">Environmental Impact</span>
          </div>
          <p className="text-sm leading-relaxed">{analysis.environmentalImpact}</p>
        </div>

        <button 
          onClick={onReset}
          className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center justify-center space-x-2 shadow-lg shadow-emerald-200"
        >
          <i className="fas fa-camera"></i>
          <span>Scan Another Item</span>
        </button>
      </div>
    </div>
  );
};

export default WasteResult;
