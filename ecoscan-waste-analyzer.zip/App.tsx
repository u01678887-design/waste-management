
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import CameraView from './components/CameraView';
import WasteResult from './components/WasteResult';
import History from './components/History';
import { analyzeWasteImage } from './services/geminiService';
import { WasteAnalysis, ScanHistoryItem, AppState } from './types';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [currentAnalysis, setCurrentAnalysis] = useState<WasteAnalysis | null>(null);
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('waste_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history");
      }
    }
  }, []);

  // Save history to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('waste_history', JSON.stringify(history.slice(0, 20)));
  }, [history]);

  const handleCapture = async (base64: string) => {
    setAppState(AppState.ANALYZING);
    setError(null);
    try {
      const result = await analyzeWasteImage(base64);
      setCurrentAnalysis(result);
      
      // Add to history
      const historyItem: ScanHistoryItem = {
        ...result,
        id: Date.now().toString(),
        timestamp: Date.now(),
        imageUrl: `data:image/jpeg;base64,${base64}`
      };
      setHistory(prev => [historyItem, ...prev]);
      setAppState(AppState.RESULT);
    } catch (err: any) {
      setError(err.message || "Something went wrong during analysis.");
      setAppState(AppState.IDLE);
    }
  };

  const resetScanner = () => {
    setAppState(AppState.IDLE);
    setCurrentAnalysis(null);
    setError(null);
  };

  const handleSelectHistory = (item: ScanHistoryItem) => {
    setCurrentAnalysis(item);
    setAppState(AppState.RESULT);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header />
      
      <main className="flex-1 max-w-xl mx-auto w-full px-4 py-8">
        {/* Banner */}
        {appState === AppState.IDLE && (
          <div className="mb-8 text-center animate-in fade-in slide-in-from-top-4 duration-700">
            <h2 className="text-3xl font-black text-slate-800 tracking-tight leading-tight">
              Small Steps,<br/><span className="text-emerald-600">Big Impact.</span>
            </h2>
            <p className="mt-3 text-slate-500 text-sm max-w-xs mx-auto">
              Scan your waste to learn the best way to recycle or dispose of it responsibly.
            </p>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center space-x-3 text-red-700 animate-bounce">
            <i className="fas fa-circle-exclamation text-xl"></i>
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        <div className="space-y-8">
          {(appState === AppState.IDLE || appState === AppState.ANALYZING) ? (
            <CameraView 
              onCapture={handleCapture} 
              isAnalyzing={appState === AppState.ANALYZING} 
            />
          ) : currentAnalysis ? (
            <WasteResult 
              analysis={currentAnalysis} 
              onReset={resetScanner} 
            />
          ) : null}

          {appState !== AppState.ANALYZING && (
            <History 
              history={history} 
              onSelectItem={handleSelectHistory} 
            />
          )}
        </div>
      </main>

      <footer className="py-8 border-t border-gray-100 text-center text-gray-400 text-[10px] font-medium uppercase tracking-widest px-4">
        <p>Built for a greener future &copy; {new Date().getFullYear()} EcoScan AI</p>
        <div className="flex justify-center space-x-4 mt-2">
          <i className="fab fa-github hover:text-emerald-500 cursor-pointer transition-colors"></i>
          <i className="fab fa-twitter hover:text-emerald-500 cursor-pointer transition-colors"></i>
        </div>
      </footer>

      {/* Persistent CTA - Only show when scrolled past scanner on result page or something */}
      {appState === AppState.RESULT && (
        <div className="fixed bottom-6 left-0 right-0 flex justify-center px-6 md:hidden pointer-events-none">
          <button 
            onClick={resetScanner}
            className="pointer-events-auto px-8 py-4 bg-emerald-600 text-white rounded-full font-bold shadow-xl shadow-emerald-200 flex items-center space-x-2 animate-in slide-in-from-bottom-10"
          >
            <i className="fas fa-plus"></i>
            <span>New Scan</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
