
export interface WasteAnalysis {
  itemName: string;
  category: 'Recyclable' | 'Compostable' | 'Landfill' | 'Hazardous' | 'E-Waste' | 'Unknown';
  materialType: string;
  disposalInstructions: string;
  sustainabilityTip: string;
  recyclabilityScore: number; // 0-100
  environmentalImpact: string;
}

export interface ScanHistoryItem extends WasteAnalysis {
  id: string;
  timestamp: number;
  imageUrl: string;
}

export enum AppState {
  IDLE = 'IDLE',
  SCANNING = 'SCANNING',
  ANALYZING = 'ANALYZING',
  RESULT = 'RESULT'
}
