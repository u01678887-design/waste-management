
import { GoogleGenAI, Type } from "@google/genai";
import { WasteAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeWasteImage(base64Image: string): Promise<WasteAnalysis> {
  const model = 'gemini-3-flash-preview';
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: `Identify the object in this image as a potential waste material. Analyze its composition and provide disposal instructions. 
          Respond ONLY with a JSON object following the specified schema.`
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          itemName: { type: Type.STRING, description: "Name of the item identified" },
          category: { 
            type: Type.STRING, 
            enum: ['Recyclable', 'Compostable', 'Landfill', 'Hazardous', 'E-Waste', 'Unknown'],
            description: "Disposal category" 
          },
          materialType: { type: Type.STRING, description: "Specific material (e.g., HDPE Plastic, Corrugated Cardboard)" },
          disposalInstructions: { type: Type.STRING, description: "Step-by-step instructions on how to dispose of it properly" },
          sustainabilityTip: { type: Type.STRING, description: "A tip on how to reduce use of this item or a better alternative" },
          recyclabilityScore: { type: Type.NUMBER, description: "Score from 0 to 100 on how recyclable the item is" },
          environmentalImpact: { type: Type.STRING, description: "Brief description of the environmental cost of this item" },
        },
        required: ["itemName", "category", "materialType", "disposalInstructions", "sustainabilityTip", "recyclabilityScore", "environmentalImpact"]
      },
    },
  });

  try {
    const analysis = JSON.parse(response.text || "{}") as WasteAnalysis;
    return analysis;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Analysis failed. Please try again.");
  }
}
